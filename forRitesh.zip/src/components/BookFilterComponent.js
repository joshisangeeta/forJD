import React from 'react';
import Showlist from './Showlist';
import { searchBooks } from '../actions/books';
import { connect } from 'react-redux';
class BookFilterComponent extends React.Component {
    constructor(props) {
        super(props);
        this.onSearchChange = this.onSearchChange.bind(this);
       
      //  this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            searchTerm: '',
            currentlyDisplayed: this.props.books,       
            flag:false,
            error: ''
        };
    }

    onSearchChange(e) {
        const search = e.target.value;
       // alert(e.target.value);
        this.setState(() => ({ searchTerm: search,flag:true}));

        this.props.dispatch(searchBooks(search));
        this.props.history.push('/');
    }
   
    // const mapStateToProps = (state, props) => {
    //     return {
    //         searchBooks: state.searchBooks((book) =>
    //             book.id === props.match.params.id)
    //     };
    // };
    
    // export default connect(mapStateToProps)(EditBook);








    

    

    render() {
        return (
            <div>
                {this.state.error && <p className='error'>{this.state.error}</p>}
                <form onSubmit={this.onSubmit} className='add-book-form'>

                    <input type="text" placeholder="searchTerm" autoFocus
                        value={this.state.searchTerm}
                        onChange={this.onSearchChange} />
                    <br />

                    
                    <button>Search Book</button>
                </form>

               <Showlist flag={this.state.flag}></Showlist>

            </div>
        );
    }
}


export default connect()(BookFilterComponent);