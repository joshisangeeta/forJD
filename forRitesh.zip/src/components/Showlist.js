import React from 'react';
import { connect } from 'react-redux';
import BookList from './BookList'
const Showlist = (props) => (
    (props.flag)?(<div>
        <h3>Set Book information:</h3>
        <BookList
           
        /></div>):<h1>No such record</h1>
    )
   
    
;

export default connect()(Showlist);